using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controls : MonoBehaviour
{
    public List<GameObject> list;

   

    // Update is called once per frame
    void Update()
    {
        
    }
}
