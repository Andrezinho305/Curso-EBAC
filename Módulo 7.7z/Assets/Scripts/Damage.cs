using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damage : MonoBehaviour
{
    [Header("Body Parts")]
    public List<body> body;

    [Header("Health")]
    public float health = 10f;
    private float damage = 0.5f;

    [Header("Cor")]
    public SpriteRenderer _cor;

           void Update()
    {
        if(Input.GetKeyDown(KeyCode.A))
        {
            health -= damage;                     
        }
        else if(Input.GetKey(KeyCode.A))
        {
            _cor.color = Color.red;            
        }
        else
        {
            _cor.color = Color.white;
        }
        
    }
}

[System.Serializable]
public class body
{
    public SpriteRenderer parts;



}