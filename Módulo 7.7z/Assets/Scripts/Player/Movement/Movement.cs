using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    #region Variaveis

    [Header("Movement")]

    private Rigidbody2D rigidBody;
    public float height;
    public float speed;
    private float move;
    public bool isJump;

    [Header("Shooting")]
    public GameObject projectile;
    public Transform shootPoint;
    public PoolManager poolManager;

    #endregion

    void Start()
    {
        rigidBody = GetComponent<Rigidbody2D>();
    }

    void Update()
    {

        move = Input.GetAxis("Horizontal");
        rigidBody.velocity = new Vector2(move * speed, rigidBody.velocity.y);


        if (Input.GetKeyDown(KeyCode.Space) && !isJump) // se apertar espa�o e a condi��o for "false" (de "nao est� pulando"), pula
        {
            rigidBody.velocity = Vector2.up * height;
            isJump = true; // altera a condi��o que impede um segundo pulo no ar
        }
        else if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            Debug.Log("pew");
            SpawnObject();
        }
    }

    #region Collision Check
    private void OnCollisionEnter2D(Collision2D other) // verifica colis�o do rigidbody e caso ocorra reseta a condi��o necessaria para pulo, permitindo pular novamente
    {
        Debug.Log("Touchy");
        if (other.transform.tag == "Floor")
        {
            isJump = false;
        }
    }

    #endregion


    private void SpawnObject()
    {
        var obj = poolManager.GetPooledObject();
        obj.SetActive(true);
        obj.GetComponent<Projectile>().StartProjectile();
        obj.transform.SetParent(null);
        obj.transform.position = shootPoint.transform.position;

        Debug.Log("pew");
    }

}
