using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class EnemyData : ScriptableObject
{
    [Header("Health")]
    public int baseLife = 5;
    public int takeDamage = 1;

    [Header("Jump Height")]
    public float height = 5f;

    [Header("Color")]
    public Color enemyColor = Color.cyan;
}
