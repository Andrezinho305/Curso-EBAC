using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//enum identificando os animais a serem lidos
public enum Animal
{
    Dog,
    Cat,
    Fish,
    Pig
}

//classe a ser referenciada nos inputs
[System.Serializable]
public class AnimalSetup
{
    public Animal animalName;
}



public class InputChecker : MonoBehaviour
{
    public List<AnimalSetup> animalList;

    public KeyCode keyCode1 = KeyCode.Alpha1;
    public KeyCode keyCode2 = KeyCode.Alpha2;
    public KeyCode keyCode3 = KeyCode.Alpha3;
    public KeyCode keyCode4 = KeyCode.Alpha4;

    #region Print Animals
    public void keyDog()
    {
        foreach (AnimalSetup animal in animalList)
        {
            if (animal.animalName == Animal.Dog)
                Debug.Log(Animal.Dog);
        }
    }

    public void keyCat()
    {
        foreach (AnimalSetup animal in animalList)
        {
            if (animal.animalName == Animal.Cat)
                Debug.Log(Animal.Cat);
        }
    }

    public void keyFish()
    {
        foreach (AnimalSetup animal in animalList)
        {
            if (animal.animalName == Animal.Fish)
                Debug.Log(Animal.Fish);
        }
    }

    public void keyPig()
    {
        foreach (AnimalSetup animal in animalList)
        {
            if (animal.animalName == Animal.Pig)
                Debug.Log(Animal.Pig);
        }
    }
    #endregion

    private void KeyChecker(Animal a)
    {
        switch (a)
        {
            case Animal.Dog:
                keyDog();
                break;
            case Animal.Cat:
                keyCat();
                break;
            case Animal.Fish:
                keyFish();
                break;
                case Animal.Pig:
                keyPig();
                break;
            default:
                Debug.Log("");
                break;
        }

    }

    
    void Update()
    {
        if (Input.GetKeyDown(keyCode1))
        {
            KeyChecker(Animal.Dog);
        }

        else if (Input.GetKeyDown(keyCode2))
        {
            KeyChecker(Animal.Cat);
        }

        else if (Input.GetKeyDown(keyCode3))
        {
            KeyChecker(Animal.Fish);
        }

        else if (Input.GetKeyDown(keyCode4))
        {
            KeyChecker(Animal.Pig);
        }

    }
}

