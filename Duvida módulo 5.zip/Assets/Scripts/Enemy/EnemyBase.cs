using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBase : MonoBehaviour
{
    public EnemyData enemyData;
    protected int _currentLife;
    protected int _damage;


    private void Awake()
    {
        _currentLife = enemyData.baseLife;
        _damage = enemyData.takeDamage;
    }
 
    public void Kill()
    {
        Destroy(gameObject);
    }

    public void Damage()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("vida: " + _currentLife);
            _currentLife -= _damage;
        }
        if (_currentLife <= 0) Kill();
    }

    private void Update()
    {
        Damage();
    }

}



