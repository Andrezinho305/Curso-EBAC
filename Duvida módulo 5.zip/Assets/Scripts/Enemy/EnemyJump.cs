using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyJump : EnemyBase
{
    private Rigidbody2D rigidBody;
    private float jump;
    private int health;
          
    private void Awake()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        jump = enemyData.height;
        Debug.Log("current health:" + health);
    }
 
    void Update()
    {
        
        if (Input.GetKeyDown(KeyCode.Space))
        {
            
            rigidBody.velocity = Vector2.up * jump;
            Damage();
        }
    }
}
