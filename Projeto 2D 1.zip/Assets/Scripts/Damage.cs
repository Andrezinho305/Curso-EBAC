using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damage : MonoBehaviour
{
    [Header("Health")]
    public float health = 10f;
    private float damage = 0.5f;

    [Header("Colour")]
    public SpriteRenderer _cor;

    void Start()
    {
       

    }

   
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.A))
        {
            health -= damage;

            
        }
        else if(Input.GetKey(KeyCode.A))
        {
            _cor.color = Color.red;
            

        }
        else
        {
            _cor.color = Color.white;

        }

    }
}
