using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Projectile : MonoBehaviour
{
    public float speed = 5f;
    public float timeToReset = 5f;

    public string tagToLook = "Enemy";

    public Action OnHitTarget;

    void Update()
    {
        transform.position += transform.right * Time.deltaTime * speed; //adiciona movimento em um objeto 2D para a direita em um timer fixo e velocidade predefinida
    }

    public void StartProjectile()
    {
        Invoke(nameof(FinishUsage), timeToReset);
    }

    private void FinishUsage()
    {
        gameObject.SetActive(false);
        OnHitTarget = null;
    }

}
