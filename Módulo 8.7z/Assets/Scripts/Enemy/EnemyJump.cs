using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyJump : EnemyBase
{
    private Rigidbody2D rigidBody;

          
    private void Awake()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        
        Debug.Log("current health:" + enemyData.baseLife);
    }
 
    void Update()
    {
        
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rigidBody.velocity = Vector2.up * enemyData.height;
            Damage();
        }
    }
}
