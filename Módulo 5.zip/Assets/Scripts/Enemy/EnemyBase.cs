using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBase : MonoBehaviour
{
    public EnemyData enemyData;
    protected int _currentLife;
    protected int _damage;

    public void Kill()
    {
        Destroy(gameObject);
    }

    public void Damage()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("vida: " + enemyData.baseLife);
            enemyData.baseLife -= enemyData.takeDamage;
        }
        if (enemyData.baseLife <= 0) Kill();
    }

    private void Update()
    {
        Damage();
    }

}



