public interface IDamageable
{
    void Damage();
}

public interface IKillable
{
    void Kill();
}

